# team-members-extension

A Twitch extension to display all users who are in a Twitch stream in a panel, and their viewership (if they're live).

This extension is written in Web Components using [Lit](https://lit.dev), and makes all of its data calls through the [public Twitch API](https://dev.twitch.tv/docs/api).
